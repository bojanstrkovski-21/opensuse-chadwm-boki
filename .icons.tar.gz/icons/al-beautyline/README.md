# BeautyLine

BeautyLine icon theme for Garuda Linux.

This is a fork of Beautyline by sajjad606.
also includes icons from candy-icons by EliverLara.

https://www.pling.com/u/sajjad606/

https://www.opendesktop.org/p/1425426/


https://gitlab.com/garuda-linux/themes-and-settings/artwork/beautyline
