Combination of two icon themes
